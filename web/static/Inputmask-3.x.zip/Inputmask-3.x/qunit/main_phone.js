define([
	"qunit",
	"tests_phone_world",
	"tests_phonebe",
	"tests_phonenl",
	"tests_phoneru"
], function(qunit) {
	qunit.load();
	qunit.start();
});
